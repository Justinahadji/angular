let dbConfig = require("../Utilities/mysqlConfig");



let getItem = (criteria, callback) => {
    //criteria.item_id ? conditions += ` and item_id = '${criteria.item_id}'` : true;
    dbConfig.getDB().query(`select * from shop_items where 1`,criteria, callback);
}

let getItemDetail = (criteria, callback) => {
	let conditions = "";
    criteria.id ? conditions += ` and id = '${criteria.id}'` : true;
    dbConfig.getDB().query(`select * from shop_items where 1 ${conditions}`, callback);
}

let createItem = (dataToSet, callback) => {
    dbConfig.getDB().query("insert into shop_items set ? ", dataToSet, callback);
}

let deleteItem = (criteria, callback) => {
    let conditions = "";
   criteria.id ? conditions += ` and id = '${criteria.id}'` : true;
   dbConfig.getDB().query(`delete from shop_items where 1 ${conditions}`, callback);

}

let updateItem = (criteria,dataToSet,callback) => {
	let conditions = "";
    let setData = "";
    criteria.id ? conditions += ` and id = '${criteria.id}'` : true;
    dataToSet.category ? setData += `category = '${dataToSet.category}'` : true;
    dataToSet.item_name ? setData += `, item_name = '${dataToSet.item_name}'` : true;
    dbConfig.getDB().query(`UPDATE shop_items SET ${setData} where 1 ${conditions}`, callback);
}
module.exports = {
    getItem : getItem,
    createItem : createItem,
    deleteItem : deleteItem,
    updateItem : updateItem,
    getItemDetail : getItemDetail
}