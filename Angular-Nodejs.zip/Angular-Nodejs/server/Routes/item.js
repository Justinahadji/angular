let express = require('express'),
    router = express.Router(),
    util = require('../Utilities/util'),
    articleService = require('../Services/item');


/**Add/Create item */
router.post('/add-item', (req, res) => {
    articleService.createItem(req.body, (data) => {
        res.send(data);
    });
});

/**Update item */
router.put('/update-item', (req, res) => {
    articleService.updateItem(req.body, (data) => {
        res.send(data);
    });
});

/**Delete item */
router.delete('/delete-item', (req, res) => {
    articleService.deleteItem(req.query, (data) => {
        res.send(data);
    });
});

/**List of all items */
router.get('/get-item', (req, res) => {
    articleService.getItem(req.query, (data) => {
        res.send(data);
    });
});
/**get item by id*/
router.get('/get-item-by-id', (req, res) => {
    articleService.getItemById(req.query, (data) => {
        res.send(data);
    });
});

module.exports = router;
