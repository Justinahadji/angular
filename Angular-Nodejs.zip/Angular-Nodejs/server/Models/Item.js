let mysqlConfig = require("../Utilities/mysqlConfig");

let initialize = () => {
    mysqlConfig.getDB().query("create table IF NOT EXISTS shop_items (id INT auto_increment primary key, category VARCHAR(30), item_name VARCHAR(24))");

}

module.exports = {
    initialize: initialize
}