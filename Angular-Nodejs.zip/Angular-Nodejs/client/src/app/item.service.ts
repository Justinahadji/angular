import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Item } from './item';

@Injectable()
export class ItemService {
    //URL for CRUD operations
	itemUrl = "http://localhost:3000/article";
	//Create constructor to get Http instance
	constructor(private http:Http) { 
	}
	
	//Fetch all articles
    getAllItems(): Observable<Item[]> {
        return this.http.get(this.itemUrl+"/get-item")
		   		.map(this.extractData)
		        .catch(this.handleError);

    }
	//Create article
    createItem(article: Item):Observable<number> {
	    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: cpHeaders });
        return this.http.post(this.itemUrl+"/add-item", article, options)
               .map(success => success.status)
               .catch(this.handleError);
    }
	//Fetch article by id
    getItemById(itemId: string): Observable<Item> {
		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let options = new RequestOptions({ headers: cpHeaders });
		console.log(this.itemUrl +"/get-item-by-id?id="+ itemId);
		return this.http.get(this.itemUrl +"/get-item-by-id?id="+ itemId)
			   .map(this.extractData)
			   .catch(this.handleError);
    }	
	//Update article
    updateItem(article: Item):Observable<number> {
	    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let options = new RequestOptions({ headers: cpHeaders });
        return this.http.put(this.itemUrl +"/update-item", article, options)
               .map(success => success.status)
               .catch(this.handleError);
    }
    //Delete article	
    deleteItemById(itemId: string): Observable<number> {
		let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
		let options = new RequestOptions({ headers: cpHeaders });
		return this.http.delete(this.itemUrl +"/delete-item?id="+ itemId)
			   .map(success => success.status)
			   .catch(this.handleError);
    }	
	private extractData(res: Response) {
		let body = res.json();
        return body;
    }
    private handleError (error: Response | any) {
		console.error(error.message || error);
		return Observable.throw(error.status);
    }
}