import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ItemService } from './item.service';
import { Item } from './item';

@Component({
   selector: 'app-article',
   templateUrl: './item.component.html',
   styleUrls: ['./item.component.css','./styles.css']
})
export class ItemComponent implements OnInit { 
   //Component properties
   allItems: Item[];
   statusCode: number;
   requestProcessing = false;
   itemIdToUpdate = null;
   processValidation = false;
   //Create form
   itemForm = new FormGroup({
       title: new FormControl('', Validators.required),
       category: new FormControl('', Validators.required)	   
   });
   //Create constructor to get service instance
   constructor(private itemService: ItemService) {
   }
   //Create ngOnInit() and and load articles
   ngOnInit(): void {
	   this.getAllItems();
   }   
   //Fetch all items

   getAllItems() {
		this.itemService.getAllItems()
		  .subscribe(
                data => this.allItems = data,
				errorCode =>  this.statusCode = errorCode);  
				
   }
   //Handling create and update item
   onItemFormSubmit() {
	  this.processValidation = true;   
	  if (this.itemForm.invalid) {
	       return; //Validation failed, exit from method.
	  }   
	  //Form is valid, now perform create or update
      this.preProcessConfigurations();
	  let article = this.itemForm.value;
	  if (this.itemIdToUpdate === null) {  
	    //Generate article id then create article
        this.itemService.getAllItems()
	     .subscribe(articles => {
			 
		   //Generate item id	 
		   let articleId = 1;
		   article.id = articleId;
		   console.log(article,'this is form data---');
		   //add item
     	   this.itemService.createItem(article)
			  .subscribe(successCode => {
					this.statusCode = successCode;
					this.getAllItems();	
					this.backToCreateItem();
				 },
				 errorCode => this.statusCode = errorCode
			   );
		 });		
	  } else {  
   	    //Handling update item
        article.id = this.itemIdToUpdate; 		
	    this.itemService.updateItem(article)
	      .subscribe(successCode => {
		            this.statusCode = successCode;
				    this.getAllItems();	
					this.backToCreateItem();
			    },
		        errorCode => this.statusCode = errorCode);	  
	  }
   }
   //Load item by id to edit
   loadItemToEdit(articleId: string) {
      this.preProcessConfigurations();
      this.itemService.getItemById(articleId)
	      .subscribe(article => {
		            this.itemIdToUpdate = article.id;   
					this.itemForm.setValue({ title: article.item_name, category: article.category });
					this.processValidation = true;
					this.requestProcessing = false;   
		        },
		        errorCode =>  this.statusCode = errorCode);   
   }
   //Delete item
   deleteItem(articleId: string) {
      this.preProcessConfigurations();
      this.itemService.deleteItemById(articleId)
	      .subscribe(successCode => {
		            //this.statusCode = successCode;
					//Expecting success code 204 from server
					this.statusCode = 204;
				    this.getAllItems();	
				    this.backToCreateItem();
			    },
		        errorCode => this.statusCode = errorCode);    
   }
   //Perform preliminary processing configurations
   preProcessConfigurations() {
      this.statusCode = null;
	  this.requestProcessing = true;   
   }
   //Go back from update to create
   backToCreateItem() {
      this.itemIdToUpdate = null;
      this.itemForm.reset();	  
	  this.processValidation = false;
   }
}
    