import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
   template: `
				<app-article></app-article>
             `
})
export class AppComponent { 
}
    