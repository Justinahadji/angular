export class Item {
   constructor(public id: number, public item_name: string, public category: string) { 
   }
} 