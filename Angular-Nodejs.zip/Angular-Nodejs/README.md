**Angular and NodeJS Shop APP**
===============================================

- - -


CONFIGURATION AND INSTALLATION
-------------------------------

Download the zip from the jsonworld.com

 - Extract the code from zip
 - Change the database configurations.
 - Run  ``npm install``
 - Run ``npm start`` command

